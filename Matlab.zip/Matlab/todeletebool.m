bool a
a=0
a+1