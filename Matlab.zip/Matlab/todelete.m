if('0')
    'hey'
end
