%Test nyquist ?
x=0:0.0001:10;
y=sin(x);
plot(x,y)
