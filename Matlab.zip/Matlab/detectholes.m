function [  ] = detectholes( img,n_holes)
% Detect (binary and bwlabel) and measure (use of approxgauss on 3-lines-wide image)
%holes on an image






end

