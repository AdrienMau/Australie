numb=str2double('hey');

numb
numb==NaN